require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;

if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 16 || ADMIN_PASSWORD === "change-this-to-a-long-random-password") {
  console.error("Set ADMIN_PASSWORD in .env to a unique password of at least 16 characters.");
  process.exit(1);
}

if (process.env.TRUST_PROXY === "true") app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public"), { index: "index.html" }));

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 40,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Слишком много запросов. Подожди минуту и попробуй снова." }
});
app.use("/api", apiLimiter);

// The bot token is kept only in server memory and is never written to disk.
let botToken = "";
let botInfo = null;
const events = [];
function logEvent(type, message) {
  events.unshift({ id: Date.now() + Math.random(), time: new Date().toISOString(), type, message: String(message).slice(0, 240) });
  if (events.length > 100) events.length = 100;
}
function authorized(req, res, next) {
  const supplied = req.get("x-admin-password") || "";
  const a = Buffer.from(supplied);
  const b = Buffer.from(ADMIN_PASSWORD);
  const crypto = require("crypto");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Неверный пароль панели." });
  }
  next();
}
async function telegram(method, body = {}) {
  if (!botToken) throw new Error("Сначала подключи Telegram-бота.");
  const response = await fetch(`https://api.telegram.org/bot${botToken}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(15000)
  });
  const data = await response.json();
  if (!response.ok || !data.ok) throw new Error(data.description || `Telegram API error (${response.status})`);
  return data.result;
}
app.get("/api/status", authorized, (req, res) => {
  res.json({ connected: Boolean(botToken && botInfo), bot: botInfo ? { id: botInfo.id, username: botInfo.username, first_name: botInfo.first_name } : null });
});
app.post("/api/connect", authorized, async (req, res) => {
  const token = String(req.body.token || "").trim();
  if (!/^\d{5,}:[A-Za-z0-9_-]{20,}$/.test(token)) return res.status(400).json({ error: "Проверь формат токена BotFather." });
  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/getMe`, { signal: AbortSignal.timeout(15000) });
    const data = await response.json();
    if (!response.ok || !data.ok) return res.status(400).json({ error: data.description || "Telegram не принял токен." });
    botToken = token;
    botInfo = data.result;
    logEvent("success", `Подключён бот @${botInfo.username}`);
    res.json({ connected: true, bot: { id: botInfo.id, username: botInfo.username, first_name: botInfo.first_name } });
  } catch (err) {
    res.status(502).json({ error: "Не удалось связаться с Telegram: " + err.message });
  }
});
app.post("/api/disconnect", authorized, (req, res) => {
  if (botInfo) logEvent("info", `Отключён бот @${botInfo.username}`);
  botToken = "";
  botInfo = null;
  res.json({ ok: true });
});
app.post("/api/send", authorized, async (req, res) => {
  const chatId = String(req.body.chatId || "").trim();
  const text = String(req.body.text || "");
  const sticker = String(req.body.sticker || "").trim();
  const parseMode = req.body.parseMode === "HTML" ? "HTML" : "";
  const buttons = Array.isArray(req.body.buttons) ? req.body.buttons.slice(0, 4) : [];
  if (!chatId || chatId.length > 100) return res.status(400).json({ error: "Укажи корректный Chat ID или @username." });
  if (!text.trim() && !sticker) return res.status(400).json({ error: "Добавь текст или file_id стикера." });
  try {
    let result;
    if (sticker) {
      result = await telegram("sendSticker", { chat_id: chatId, sticker });
      if (text.trim()) await telegram("sendMessage", { chat_id: chatId, text, ...(parseMode ? { parse_mode: parseMode } : {}) });
    } else {
      const keyboard = buttons
        .filter(b => b && String(b.text || "").trim() && String(b.url || "").trim())
        .map(b => ({ text: String(b.text).slice(0, 64), url: String(b.url).slice(0, 300) }));
      const reply_markup = keyboard.length ? { inline_keyboard: keyboard.map(b => [b]) } : undefined;
      result = await telegram("sendMessage", { chat_id: chatId, text, ...(parseMode ? { parse_mode: parseMode } : {}), ...(reply_markup ? { reply_markup } : {}) });
    }
    logEvent("success", `${sticker ? "Стикер" : "Сообщение"} отправлено в ${chatId}`);
    res.json({ ok: true, messageId: result.message_id });
  } catch (err) {
    logEvent("error", `Ошибка отправки в ${chatId}: ${err.message}`);
    res.status(400).json({ error: err.message });
  }
});
app.get("/api/events", authorized, (req, res) => res.json({ events }));
app.get("/api/health", (req, res) => res.json({ ok: true }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Внутренняя ошибка сервера." });
});
app.listen(PORT, () => console.log(`GIGGER HOST running on http://localhost:${PORT}`));
